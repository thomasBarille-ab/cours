package ExamIntroJava_Barille_Thomas_group1;

public class Controleur {

    Race race;

    Controleur(Race race) {
        this.race = race;
    }

    public boolean verifierVaisseau() {
        if(

        )
        return false;
    }
}
