if(typeof droidGlobal === 'undefined'){

	var droidDiv = null, result = 'ok', droidIdValue = 0, droidIdName = 'droidref';
		
	droidGlobal = {connection:new WebSocket('ws://127.0.0.1:' + arguments[0] + '/' + arguments[1]), catchMode:true, element:null};
	droidGlobal.sendData = function(data){
		if(this.catchMode == true){
			if(droidGlobal.connection != null){
				droidGlobal.connection.send(JSON.stringify(data) + String.fromCharCode(127));
			}
		}
	};
	
	droidGlobal.setCatchMode = function(value){
		this.catchMode = value;
		showDroidPopup(value);
	};
	
	droidGlobal.capture = function(){
		this.sendData({type:'capture', element:getAttributes(this.element, true)});
	};
	
	droidGlobal.mouseMove = function(elem){
		this.element = elem;
		this.sendData({type:'hover', element:getAttributes(this.element, false), window:[window.screenX, window.screenY, window.screenX + window.outerWidth, window.screenY + window.outerHeight]});
	};
	
	droidGlobal.spareData = function(tx, st){
		this.sendData({type:'spareData', text:['text', tx.replace(/(\r\n|\n|\r)/gm, '')], style:st});
	};
	
	droidGlobal.mouseOut = function(){
		this.sendData({type:'mouseout'});
	};
		
	droidGlobal.connection.onopen = function(){
	
		droidGlobal.sendData({type:'initCatcher', data:document.hasFocus()});

		document.onmousemove = function(event){
			droidGlobal.mouseMove(document.elementFromPoint(event.clientX, event.clientY));
		};
		
		window.onmouseout = function() {
    		droidGlobal.mouseOut();
		};
		
		document.onmouseout = function(event){
			droidGlobal.mouseOut();
		};
		
		window.onblur = function(event){
			droidGlobal.mouseOut();
		};
	};
	
	droidGlobal.connection.onmessage = function(event){
	
		var paramsEvent = JSON.parse(event.data);
		
		if(paramsEvent.action=='droidImage'){
			
			var droidImage = new Image();
			droidImage.onload = function onload() {
	
				droidDiv = document.createElement('div');
				droidDiv.setAttribute('style', 'left: 2px; top: -80px; overflow: visible; display: block; position: fixed; z-index: 9999999; opacity: 0; pointer-events: none; transform: matrix(0.3, 0, 0, 1.6, 0, 0);');
				droidDiv.appendChild(droidImage);
				document.body.appendChild(droidDiv);
							
				loadScript('https://cdnjs.cloudflare.com/ajax/libs/gsap/1.18.2/TweenMax.min.js', function(){
					loadScript('https://cdnjs.cloudflare.com/ajax/libs/gsap/1.18.2/plugins/TextPlugin.min.js', function(){
						greensockLoaded();
					})
				})
			};
			
			var greensockLoaded = function (){
				showDroidPopup(paramsEvent.catchMode);
			};
			
			droidImage.src = "data:image/png;base64, " + paramsEvent.data;
						
		}else if(paramsEvent.action=='capture'){
			droidGlobal.capture();
		}else if(paramsEvent.action=='spareData'){
		
			var queryString = paramsEvent.tag + "[" + droidIdName + "='" + paramsEvent.id + "']";
			var elements = window.document.querySelectorAll(queryString);
			var elem = elements[0];
			
			droidGlobal.spareData(elem.innerText || elem.textContent, window.getComputedStyle(elem, null));
			
		}else if(paramsEvent.action=='catchMode'){
			droidGlobal.setCatchMode(paramsEvent.value);
		}else if(paramsEvent.action=='hoverMode'){
			showDroidPopup(!paramsEvent.value);
		}
	};
	
	function showDroidPopup(value){
		if(value){
			TweenMax.to(droidDiv, 0.6, {top:'0px', opacity:0.93, scaleX:1, scaleY:1, ease:Elastic.easeOut.config(1, 0.5)});
		}else{
			TweenMax.to(droidDiv, 1.0, {top:'-80px', opacity:0.4, scaleX:0.6, scaleY:1.6, ease:Elastic.easeInOut.config(1, 0.5)});
		}
	};
		
	function loadScript(url, callback){
	    var script = document.createElement('script');
	    script.type = 'text/javascript';
	
	    if (script.readyState){
	        script.onreadystatechange = function(){
	            if (script.readyState == 'loaded' || script.readyState == 'complete'){
	                script.onreadystatechange = null;
	                callback();
	            }
	        }
	    }else{
	        script.onload = function(){
	            callback();
	        }
	    };
	
	    script.src = url;
	    document.getElementsByTagName('head')[0].appendChild(script);
	};
	
	function getAttributes(element, addParent){

		if(!element.hasAttribute(droidIdName)){
			element.setAttribute(droidIdName, droidIdValue++);
		};
		
		var dataObject = {droidref:element.getAttribute(droidIdName), tag:element.tagName, bound:getBound(element), attributes:[]};
		
		for(var i=0, len=element.attributes.length; i<len; i++){
			var attrib = element.attributes[i];
			if(attrib.name != droidIdName && attrib.name != 'value'){
				dataObject.attributes.push([attrib.name, attrib.value]);
			}
		};
		
		if(element.value != null){
			dataObject.attributes.push(['value', element.value]);
		};
		
		if(addParent && element.parentElement != null && element.parentElement.tagName != 'HTML'){
			dataObject.parent = getAttributes(element.parentElement, true);
		};
		
		return dataObject;
	};
			
	function screenPosition (el) {
	    var xPos = 0, yPos = 0;
		while (el) {
		    if (el.tagName == "BODY") {
				var xScroll = el.scrollLeft || document.documentElement.scrollLeft;
				var yScroll = el.scrollTop || document.documentElement.scrollTop;
		 
				xPos += (el.offsetLeft - xScroll + el.clientLeft);
				yPos += (el.offsetTop - yScroll + el.clientTop);
		    } else {
				xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
				yPos += (el.offsetTop - el.scrollTop + el.clientTop);
		    };
			el = el.offsetParent;
		};
	    return [xPos + window.screenX + 8, yPos + window.screenY + window.outerHeight - window.innerHeight - 8];
	};
    
	function getBound(el) {
		var position = screenPosition(el);
		return [position[0], position[1], el.offsetWidth, el.offsetHeight];
	};
};